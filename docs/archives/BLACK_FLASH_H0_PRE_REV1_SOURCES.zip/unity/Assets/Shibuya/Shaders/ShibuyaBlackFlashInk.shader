Shader "JJK/Shibuya/BlackFlashInk"
{
    Properties { _Color("Color", Color)=(3,.01,.02,1) _Age("Age",Float)=0 _Life("Life",Float)=.3 _Mode("Mode",Float)=0 _Seed("Seed",Float)=1 _ZWrite("Depth write",Float)=1 }
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Transparent-20" "RenderType"="Transparent" }
        Pass
        {
            Name "Ink" Tags { "LightMode"="SRPDefaultUnlit" }
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite [_ZWrite] ZTest LEqual Cull Back
            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            CBUFFER_START(UnityPerMaterial)
            float4 _Color; float _Age,_Life,_Mode,_Seed;
            CBUFFER_END
            struct A { float4 positionOS:POSITION; float3 normalOS:NORMAL; float4 color:COLOR; };
            struct V { float4 positionCS:SV_POSITION; float3 world:TEXCOORD0; float3 normal:TEXCOORD1; float3 local:TEXCOORD2; float4 color:COLOR; };
            V Vert(A v) {
                V o; float3 p=v.positionOS.xyz;
                float wave=sin(p.x*12+p.y*9+_Seed+_Age*35)*sin(p.z*13-p.y*7+_Age*23);
                p+=v.normalOS*(wave*.018)*saturate(_Age*30);
                o.positionCS=TransformObjectToHClip(p);o.world=TransformObjectToWorld(p);
                o.normal=TransformObjectToWorldNormal(v.normalOS);o.local=p;o.color=v.color;return o;
            }
            half4 Frag(V i):SV_Target {
                float t=saturate(_Age/max(.01,_Life));
                float n=sin(i.local.x*23+i.local.z*17+_Seed)*sin(i.local.y*19-i.local.z*11+_Age*17);
                float ndv=abs(dot(normalize(i.normal),normalize(GetWorldSpaceViewDir(i.world))));
                // Smoke is a soft dark mass; never a glowing hollow Fresnel shell. White vertex
                // tint marks the separate tiny residual discharges sharing this pooled mesh.
                if(_Mode>.5 && i.color.r<.5) {
                    float density=.52+.18*sin(i.local.x*9+i.local.y*8+_Age*4)*sin(i.local.z*11-_Age*3);
                    return half4(.007,.003,.009,pow(saturate(ndv),.65)*density*pow(1-t,1.3));
                }
                float dissolve=saturate((t-.44)/.56);
                clip((n*.25+.72)-dissolve);
                float facing=1-ndv;
                float rim=smoothstep(.78,.99,facing);
                float scar=pow(saturate(sin(i.local.y*31+i.local.z*22+_Seed)*sin(i.local.x*17-_Age*40)),12)*.15;
                float ember=(_Mode>0.5? .6:1)*saturate(rim*.8+scar*.3);
                float3 ink=float3(.004,.001,.004);
                float3 color=lerp(ink,_Color.rgb,ember)*i.color.rgb;
                float alpha=(_Mode>0.5? .65: .98)*saturate((1-t)*5)*_Color.a*i.color.a;
                return half4(color,alpha);
            }
            ENDHLSL
        }
    }
}

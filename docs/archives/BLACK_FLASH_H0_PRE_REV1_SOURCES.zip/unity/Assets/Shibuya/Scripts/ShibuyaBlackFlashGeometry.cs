using System;
using System.Collections.Generic;
using UnityEngine;

namespace JJKGame.Shibuya
{
    // Closed 3D volumes, never camera-facing flame cards. Buffers live with a pooled instance.
    public sealed class ShibuyaBlackFlashGeometry
    {
        readonly List<Vector3> vertices = new List<Vector3>(8192);
        readonly List<int> triangles = new List<int>(32768);
        readonly List<Color> colors = new List<Color>(8192);
        System.Random random;
        float R(float low, float high) => Mathf.Lerp(low, high, (float)random.NextDouble());
        Vector3 Unit() { float z=R(-1,1),a=R(0,Mathf.PI*2),s=Mathf.Sqrt(1-z*z); return new Vector3(s*Mathf.Cos(a),z,s*Mathf.Sin(a)); }
        void Vertex(Vector3 p, Color color) { vertices.Add(p); colors.Add(color); }
        void Triangle(int a,int b,int c) { triangles.Add(a);triangles.Add(b);triangles.Add(c); }
        void Tube(Vector3[] points, float width, Color color, float taper=1)
        {
            const int sides=6;int start=vertices.Count;
            for(int j=0;j<points.Length;j++) {
                Vector3 tangent=(points[Mathf.Min(j+1,points.Length-1)]-points[Mathf.Max(0,j-1)]).normalized;
                Vector3 axis=Vector3.Cross(tangent,Mathf.Abs(tangent.y)>.92f?Vector3.right:Vector3.up).normalized;
                Vector3 other=Vector3.Cross(tangent,axis);
                float fraction=(float)j/(points.Length-1);
                float radius=width*Mathf.Lerp(1, .015f,Mathf.Pow(fraction,taper))*(j%2==0?1:.65f);
                for(int k=0;k<sides;k++) {float angle=k*Mathf.PI*2/sides;
                    Vertex(points[j]+radius*(axis*Mathf.Cos(angle)+other*Mathf.Sin(angle)),color);}
                if(j==0)continue;
                for(int k=0;k<sides;k++){int a=start+(j-1)*sides+k,b=start+(j-1)*sides+(k+1)%sides,c=start+j*sides+k,d=start+j*sides+(k+1)%sides;Triangle(a,b,c);Triangle(b,d,c);}
            }
            for(int k=1;k<sides-1;k++){Triangle(start,start+k,start+k+1);int end=start+(points.Length-1)*sides;Triangle(end,end+k+1,end+k);}
        }
        void Mass(Vector3 center,Vector3 scale,float rough,Color color)
        {
            const int sides=20,rows=12;int start=vertices.Count;float seed=R(0,20);
            Vertex(center+Vector3.up*scale.y,color);
            for(int j=1;j<rows;j++)for(int k=0;k<sides;k++) {
                float a=k*Mathf.PI*2/sides,b=j*Mathf.PI/rows;
                Vector3 u=new Vector3(Mathf.Sin(b)*Mathf.Cos(a),Mathf.Cos(b),Mathf.Sin(b)*Mathf.Sin(a));
                float tear=1+rough*(Mathf.Sin(a*7+b*3+seed)*Mathf.Sin(b*9-a*3)+.5f*Mathf.Sin(a*11+b*5));
                Vertex(center+Vector3.Scale(u,scale)*Mathf.Max(.2f,tear),color);
            }
            int bottom=vertices.Count;Vertex(center-Vector3.up*scale.y,color);
            for(int k=0;k<sides;k++) {
                Triangle(start,start+1+(k+1)%sides,start+1+k);
                for(int j=0;j<rows-2;j++){int a=start+1+j*sides+k,b=start+1+j*sides+(k+1)%sides;Triangle(a,b,a+sides);Triangle(b,b+sides,a+sides);}
                int last=start+1+(rows-2)*sides;Triangle(bottom,last+k,last+(k+1)%sides);
            }
        }
        Vector3[] Branch(Vector3 origin,Vector3 direction,float length,int count=8)
        {
            var points=new Vector3[count];points[0]=origin;
            Vector3 drift=Vector3.Cross(direction,Unit()).normalized;
            for(int i=1;i<count;i++){float f=(float)i/(count-1);points[i]=origin+direction*length*f+drift*Mathf.Sin(f*6)*length*.15f+Unit()*length*.085f;}
            return points;
        }
        public void Build(Mesh mesh,int layer,ShibuyaBlackFlashProfile p,int seed)
        {
            random=new System.Random(seed);vertices.Clear();triangles.Clear();colors.Clear();
            if(layer==0) {
                for(int i=0;i<11;i++){Vector3 d=Unit();Tube(Branch(Vector3.zero,d,R(.8f,1.75f),3),R(.04f,.08f),Color.white);}
            } else if(layer==1) {
                Mass(Vector3.zero,new Vector3(.9f,1,1.1f)*p.coreSize,.4f,Color.white);
                for(int i=0;i<5;i++){Vector3 d=Unit();Mass(d*p.coreSize*.5f,new Vector3(.35f,.6f,.32f)*p.coreSize,.45f,Color.white);}
            } else if(layer==2) {
                int count=Mathf.Clamp(p.branchCount,3,24);
                for(int i=0;i<count;i++) {
                    Vector3 d=(Unit()+Vector3.forward*Mathf.Clamp01(p.forwardBias)).normalized;
                    float length=Mathf.Max(.1f,p.branchLength)*R(.55f,1.25f);
                    var path=Branch(d*.12f,d,length);Tube(path,Mathf.Clamp(p.branchWidth,.02f,.4f)*R(.65f,1.45f),Color.white,.8f);
                    for(int j=0;j<Mathf.Clamp(p.forksPerBranch,0,3);j++) {
                        int node=2+j;Vector3 fd=(d*.45f+Unit()).normalized;
                        Tube(Branch(path[node],fd,length*R(.24f,.48f),5),p.branchWidth*.42f,Color.white);
                    }
                }
            } else if(layer==3) {
                for(int i=0;i<7;i++) {
                    var points=new Vector3[15];float offset=R(0,6.28f),span=R(.6f,1.65f);
                    Quaternion rotation=Quaternion.Euler(R(-65,65),R(0,180),R(-25,25));
                    for(int j=0;j<points.Length;j++){float f=(float)j/(points.Length-1),a=offset+span*f;
                        points[j]=rotation*new Vector3(Mathf.Cos(a)*(1+.07f*Mathf.Sin(a*7)),Mathf.Sin(a),.13f*Mathf.Sin(a*4));}
                    Tube(points,R(.022f,.055f),new Color(.8f,.85f,1,.55f));
                }
            } else {
                for(int i=0;i<Mathf.Clamp(p.smokeCount,0,32);i++){
                    Vector3 d=Unit();float size=Mathf.Max(.02f,p.smokeSize)*R(.65f,1.6f);
                    Mass(d*R(.35f,1.1f),new Vector3(size,size*R(1,1.8f),size*.8f),.12f,new Color(.15f,.15f,.15f,1));
                }
                for(int i=0;i<10;i++) {Vector3 d=Unit();Tube(Branch(d*R(.4f,1.1f),d,R(.12f,.55f),4),.024f,Color.white);}
            }
            mesh.Clear();mesh.SetVertices(vertices);mesh.SetColors(colors);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();
        }
    }
}
